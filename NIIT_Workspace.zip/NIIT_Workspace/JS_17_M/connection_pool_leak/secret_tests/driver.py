import json
import os
import re
import sys

TC_NAMES = {
    "tc1": "application.properties configured with active HikariCP diagnostic settings",
    "tc2": "spring.datasource.hikari.leak-detection-threshold is set exactly to 2000",
    "tc3": "spring.datasource.hikari.connection-timeout is set exactly to 5000",
    "tc4": "logging.level.com.zaxxer.hikari is set to DEBUG",
}
TC_MARKS = {"tc1": 0, "tc2": 10, "tc3": 10, "tc4": 10}


def get_base_path():
    """Return the path to the sibling student_workspace directory."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.abspath(os.path.join(current_dir, "..", "student_workspace"))


def parse_properties(content):
    """Parse active Java .properties entries, ignoring comments and using last-wins overrides."""
    props = {}
    lines = content.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.lstrip()
        if not stripped or stripped.startswith("#") or stripped.startswith("!"):
            i += 1
            continue

        # Support trailing backslash line continuations per Java .properties rules.
        while True:
            bs_count = 0
            idx = len(line) - 1
            while idx >= 0 and line[idx] == "\\":
                bs_count += 1
                idx -= 1
            if bs_count % 2 == 1 and i + 1 < len(lines):
                i += 1
                line = line[:-1] + lines[i].lstrip()
            else:
                break

        match = re.match(r"^([A-Za-z0-9_.\-\[\]]+)\s*[=:]\s*(.*)$", line.strip())
        if match:
            key = match.group(1).strip()
            val = match.group(2).strip()
            props[key] = val
        i += 1
    return props


def evaluate_properties_content(content):
    """Evaluate active HikariCP leak-detection properties from file text."""
    results = {k: False for k in TC_NAMES}
    props = parse_properties(content)
    leak_val = props.get("spring.datasource.hikari.leak-detection-threshold")
    timeout_val = props.get("spring.datasource.hikari.connection-timeout")
    hikari_log = props.get("logging.level.com.zaxxer.hikari", "").strip().upper()

    # Require a non-default diagnostic value so untouched starter boilerplate scores 0.
    has_custom_leak = bool(leak_val) and leak_val != "0"
    has_custom_timeout = bool(timeout_val) and timeout_val != "30000"
    has_custom_log = hikari_log == "DEBUG"
    if has_custom_leak or has_custom_timeout or has_custom_log:
        results["tc1"] = True
    if leak_val == "2000":
        results["tc2"] = True
    if timeout_val == "5000":
        results["tc3"] = True
    if hikari_log == "DEBUG":
        results["tc4"] = True

    return results


def run_tests():
    """Run local validation checks against student_workspace/src/main/resources/application.properties."""
    base_path = get_base_path()
    results = {k: False for k in TC_NAMES}
    props_path = os.path.join(base_path, "src", "main", "resources", "application.properties")

    if os.path.isfile(props_path):
        try:
            with open(props_path, "r", encoding="utf-8-sig", errors="replace") as f:
                content = f.read()
            results = evaluate_properties_content(content)
        except Exception:
            pass

    return results


if __name__ == "__main__":
    test_results = run_tests()
    try:
        sol_path = os.path.join(get_base_path(), "solution.json")
        with open(sol_path, "w", encoding="utf-8") as f:
            json.dump({"results": test_results}, f)
    except Exception:
        pass

    if len(sys.argv) > 1 and sys.argv[1] == "--json":
        print(json.dumps(test_results))
    else:
        print("Running Tests for: Connection Pool Leak Identification\n")
        total_score = 0
        max_total = sum(TC_MARKS.values())
        for k in TC_NAMES:
            tc_num = k[2:]
            desc = TC_NAMES[k]
            marks = TC_MARKS[k]
            if test_results.get(k, False):
                total_score += marks
                print(f"PASS TC{tc_num} [{desc}] ({marks}/{marks})")
            else:
                print(f"FAIL TC{tc_num} [{desc}] (0/{marks})")
        print(f"\nSCORE: {total_score}/{float(max_total)}")


def verify_task_central(username, start_time_str, exam_code="UNKNOWN", **kwargs):
    """Delegate central evaluation to driver_central."""
    from driver_central import verify_task_central as _central
    return _central(username, start_time_str, exam_code, **kwargs)

import os
import subprocess
import sys


def main():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    driver_path = os.path.abspath(os.path.join(current_dir, "..", "secret_tests", "driver.py"))

    if not os.path.exists(driver_path):
        print(f"Error: Evaluation driver not found at {driver_path}", file=sys.stderr)
        sys.exit(1)

    result = subprocess.run([sys.executable, driver_path, *sys.argv[1:]], capture_output=False)
    sys.exit(result.returncode)


if __name__ == "__main__":
    main()

# Tomcat Access Log Analysis

## 1. Objective

<!-- Briefly explain the purpose of analyzing access.log. -->

## 2. Client IP Address Extraction

- **PowerShell command used:**
  ```powershell
  ```
- **Output:**
  ```text
  ```
- **Explanation:**

## 3. HTTP 500 Error Filtering

- **PowerShell command used:**

  ```powershell
  ```
- **Regex used:**

  ```regex
  ```
- **Explanation of the regex:**
- **Matching log entries:**

  ```text
  ```

## 4. Total HTTP 500 Error Count

- **Command used:**

  ```powershell
  ```
- **Result:**
- **Explanation:**

## 5. HTTP 500 Errors by Client IP

- **Command used:**
  ```powershell

  ```
- **Result:**
  ```text

  ```
- **Analysis:**

## 6. Conclusion

<!-- Explain what the analysis reveals about the application access logs. -->

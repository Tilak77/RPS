# Multi-Tier Component Mapping & Request Flow Documentation

## 1. Objective & Environment Overview
<!-- 
This document maps the multi-tier middleware architecture and traces end-to-end request and response flows across the web, servlet, application, and database tiers based on `system_inventory.json`. -->


## 2. Role Comparison: Web Server vs. Servlet Container vs. Application Server

Complete the table below based on your inspection of `system_inventory.json` and middleware concepts:

| Attribute | Web Server | Servlet Container | Enterprise Application Server |
|---|---|---|---|
| **Component in Inventory** | Nginx | Apache Tomcat | Oracle WebLogic Server |
| **Architecture Tier** | Web Tier (Edge / Reverse Proxy) | Servlet / Web Container Tier | Enterprise Application Server Tier |
| **Listen Port(s) & Protocol(s)** | 80 (HTTP), 443 (HTTPS) | 8080 (HTTP), 8443 (HTTPS) | 7001 (HTTP/T3), 7002 (HTTPS/T3S) |
| **Primary Responsibilities** | Static asset delivery, TLS termination, reverse proxying, load balancing | Executing Java Servlets and JSPs, handling web request/response lifecycles | Hosting enterprise business logic, distributed transactions, messaging, and clustering |
| **Enterprise Features (JTA/JMS/EJB)** | None | Not supported natively (servlet/JSP scope only) | Full support for JTA, JMS, EJB, and enterprise clustering |

### Key Distinctions (Web Server vs. Application Server / Servlet Container)
<!-- 
- **Nginx** acts as a lightweight web server and reverse proxy at the front of the architecture, serving static files directly and routing dynamic requests to backend servers.
- **Apache Tomcat** is a servlet container focused on running Java servlets and JSPs for web applications without full Java EE/Jakarta EE enterprise services.
- **Oracle WebLogic Server** is a full enterprise application server that provides heavy-duty middleware capabilities such as JTA transactions, JMS messaging, EJB components, and high-availability clustering. -->


## 3. End-to-End Request-Response Flow Diagram

<!-- Replace the placeholder below with a complete Mermaid or ASCII diagram showing both request and response paths, including ports and protocols from system_inventory.json. -->

```mermaid
flowchart LR
    Client[Client] -- "HTTPS (443) / HTTP (80)" --> Nginx[Nginx Web Server]
    Nginx -- "HTTP (8080)" --> Tomcat[Apache Tomcat]
    Tomcat -- "T3 / HTTP (7001)" --> WebLogic[Oracle WebLogic]
    WebLogic -- "JDBC (1521)" --> DB[(Database)]

    DB -- "Query/Tx Result" --> WebLogic
    WebLogic -- "Business Response" --> Tomcat
    Tomcat -- "HTTP Response" --> Nginx
    Nginx -- "HTTP/HTTPS Response" --> Client

```

## 4. Step-by-Step Request-Response Walkthrough

### A. Static Asset Request (`REQ-STATIC-01`: `GET /static/logo.png`)
1. **Request Path:** The client sends `GET /static/logo.png` to **Nginx** (port 80/443), which matches the `/static/` path and serves `logo.png` directly from local storage/cache without hitting Tomcat or WebLogic.
2. **Response Path:** **Nginx** sends the image file and HTTP `200 OK` response directly back to the client.

### B. REST API Request (`REQ-API-02`: `GET /api/products`)
1. **Request Path:** The client sends `GET /api/products` to **Nginx**, which reverse-proxies the `/api/` request to **Apache Tomcat** (e.g., port 8080), and Tomcat routes it to the backend API handler/service (or WebLogic if delegated).
2. **Processing:** The application layer retrieves the product list from the backend/data source and formats the JSON response.
3. **Response Path:** The response travels back through **Apache Tomcat** and **Nginx** to the client with HTTP `200 OK` and the JSON payload.

### C. Transactional Checkout Request (`REQ-TX-03`: `POST /checkout/confirm`)
1. **Request Path:** The client submits `POST /checkout/confirm` to **Nginx**, which forwards it to **Apache Tomcat** (port 8080), which in turn passes the transactional request to **Oracle WebLogic Server** (port 7001).
2. **Enterprise & DB Execution:** **Oracle WebLogic** starts a transaction (e.g., JTA), executes the order/payment persistence operations against the **Database** (e.g., JDBC port 1521), and commits or rolls back the transaction.
3. **Upstream Return:** The database returns the commit/result status to **Oracle WebLogic**, which passes the outcome back to **Apache Tomcat** and **Nginx**.
4. **Response Path:** **Nginx** returns the final checkout confirmation (or error) response to the client.

## 5. Architectural Summary
<!-- Explain why separating Web, Application/Servlet, and Database tiers improves security, scalability, and maintainability. -->
Separating the Web, Servlet/Application, and Database tiers improves **security** by keeping internal application servers and databases behind a reverse proxy/DMZ, improves **scalability** by letting each tier scale independently based on load (static traffic vs. compute vs. database I/O), and improves **maintainability** by isolating concerns so teams can update, patch, or deploy components with minimal risk to other layers.


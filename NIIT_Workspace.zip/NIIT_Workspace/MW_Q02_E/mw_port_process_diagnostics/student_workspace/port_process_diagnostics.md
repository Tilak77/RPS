# Port & Process Diagnostics Report

## 1. Objective
<!-- Briefly explain the purpose of inspecting active sockets and mapping listening ports to processes. -->


## 2. Filtering Active Listening Sockets (Ports 80 & 443)
- **PowerShell command used:**
  ```powershell

  ```
- **Regex explanation (why ports such as 8080/4433 and ESTABLISHED connections are excluded):**


- **Matching socket entries from `netstat_snapshot.txt`:**
  ```text

  ```

## 3. Mapping Listening Ports to PIDs & Process Details
- **PowerShell command used to extract PIDs and look up processes in `processes_snapshot.csv`:**
  ```powershell

  ```
- **Conflicting PID(s) and Process Name(s) identified:**
  ```text

  ```
- **Explanation:**


## 4. Filtering Processes by Name
- **PowerShell command used to list all matching processes by name:**
  ```powershell

  ```
- **Output:**
  ```text

  ```
- **Analysis (note any master/controller vs. worker processes):**


## 5. Graceful Process Termination (Live Windows PowerShell Workflow)
- **Command to verify the process before stopping (`Get-Process` / `Stop-Process -WhatIf`):**
  ```powershell

  ```
- **Command to gracefully terminate the conflicting process (`Stop-Process`):**
  ```powershell

  ```
- **Post-termination port verification command (`Get-NetTCPConnection` / `netstat -ano`):**
  ```powershell

  ```

## 6. Conclusion
<!-- Summarize the root cause of the port 80/443 binding failure and how it should be resolved. -->



Import-Module WebAdministration

$AppPoolName= "DefaultAppPool"
Set-ItemProperty -Path "IIS:\AppPools\$AppPoolName" `
    -Name "processModel.identityType" `
    -Value "NetworkService"